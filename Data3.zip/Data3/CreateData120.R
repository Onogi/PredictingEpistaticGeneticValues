DataNo<-120
#Ad x Ad interactions

#create data sets##########################################################
Ntrain<-c(1000,5000,10000)
Ntest<-1000

Prob<-matrix(c(0.25,0.5,0.25,
               0.36,0.48,0.16,
               0.49,0.42,0.09,
               0.64,0.32,0.04,
               0.81,0.18,0.01),nc=3,nr=5,byrow=T)
freq<-1

Nqtl<-c(20,100,200)
nqtl<-1

Nloci<-200
Nsim<-10
h2<-0.2

#simulate genotypes and phenotypes
for(ntrain in Ntrain){
  N<-ntrain+Ntest
  datano<-DataNo+which(ntrain==Ntrain)
  for(sim in 1:Nsim){
    Geno<-matrix(sample(0:2,N*Nloci,prob=Prob[freq,],replace=TRUE),nr=N,nc=Nloci)
    
    n<-Nqtl[nqtl]
    QTL<-1:n
    QTL.A<-QTL[seq(1,n,2)]
    QTL.B<-QTL[seq(2,n,2)]
    npair<-n/2
    
    QTL.E<-matrix(0,nr=N,nc=npair)
    for(p in 1:npair){
      QTL.E[Geno[,QTL.A[p]]==2&Geno[,QTL.B[p]]==2,p]<-1
      QTL.E[Geno[,QTL.A[p]]==0&Geno[,QTL.B[p]]==2,p]<-(-1)
      QTL.E[Geno[,QTL.A[p]]==2&Geno[,QTL.B[p]]==0,p]<-(-1)
      QTL.E[Geno[,QTL.A[p]]==0&Geno[,QTL.B[p]]==0,p]<-1     
    }
    
    Effect<-matrix(rnorm(n/2,0,1),nc=1)
    GV<-as.vector(QTL.E%*%Effect)
    write.csv(Effect,paste("Data",datano,".sim",sim,".Effect.csv",sep=""))
    
    if(h2<1){
      Pheno<-GV+rnorm(N,0,sqrt(var(GV)*((1-h2)/h2)))
    }else{
      Pheno<-GV
    }
    
    Data<-data.frame(Pheno=Pheno,GV=GV)
    Data.train<-Data[1:ntrain,]
    Data.test<-Data[(ntrain+1):N,]
    
    write.csv(Data.train,paste("Data",datano,".sim",sim,".Pheno.train.csv",sep=""))
    write.csv(Data.test,paste("Data",datano,".sim",sim,".Pheno.test.csv",sep=""))
    
    Geno.train<-Geno[1:ntrain,]
    Geno.test<-Geno[(ntrain+1):N,]
    
    write.csv(Geno.train,paste("Data",datano,".sim",sim,".Geno.train.csv",sep=""))
    write.csv(Geno.test,paste("Data",datano,".sim",sim,".Geno.test.csv",sep=""))
    
    #Geno.onehot<-matrix(0,nr=N,nc=Nloci*3)
    #for(loci in 1:Nloci){
    #  Geno.onehot[Geno[,loci]==0,(loci-1)*3+1]<-1
    #  Geno.onehot[Geno[,loci]==1,(loci-1)*3+2]<-1  
    #  Geno.onehot[Geno[,loci]==2,(loci-1)*3+3]<-1 
    #}
    
    #Geno.onehot.train<-Geno.onehot[1:ntrain,]
    #Geno.onehot.test<-Geno.onehot[(ntrain+1):N,]
    
    #write.csv(Geno.onehot.train,paste("Data",datano,"OneHot.sim",sim,".Geno.train.csv",sep=""))
    #write.csv(Geno.onehot.test,paste("Data",datano,"OneHot.sim",sim,".Geno.test.csv",sep=""))  
  }  
}




